import React, { Fragment } from 'react'
import './Product.css'

const Product = () => {
  return (
    <Fragment>
        {/* section1 */}
        
    </Fragment>
  )
}

export default Product